package capeph.orderbook;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Orderbook for a single symbol
 * Created by peter on 30/10/2015.
 */
class Book {

    private final Depth buyDepth = new Depth(Side.BUY);
    private final Depth sellDepth = new Depth(Side.SELL);
    private final Map<Long, Order> orderMap = new HashMap<>();

    private List<Trade> getTrades(Order order, Depth matchSide, Depth storeSide) {
        Matcher matcher = new Matcher(order);
        matchSide.match(matcher);
        if (matcher.remainingQuantity() > 0) { //partial or no match
            order.setQuantity(matcher.remainingQuantity());
            storeSide.add(order);
            orderMap.put(order.getId(), order);
        }
        List<Trade> trades = matcher.getAllTrades();
        for (Trade trade : trades) {
            if (trade.getRemoved() != 0) {
                orderMap.remove(trade.getRemoved());
            }
        }
        return matcher.getAllTrades();
    }

    public List<Trade> buy(Order order) {
        return getTrades(order, sellDepth, buyDepth);
    }

    public List<Trade> sell(Order order) {
        return getTrades(order, buyDepth, sellDepth);
    }

    public Collection<Level> getBids() {
        return buyDepth.getLevels();
    }

    public Collection<Level> getOffers() {
        return sellDepth.getLevels();
    }

    public Order remove(long id) {
        Order toRemove = orderMap.remove(id);
        if (toRemove != null) {
            switch (toRemove.getSide()) {
                case BUY: return buyDepth.remove(toRemove);
                case SELL: return sellDepth.remove(toRemove);
            }
        }
        return null;
    }
}
