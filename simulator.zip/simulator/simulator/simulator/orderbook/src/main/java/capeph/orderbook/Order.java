package capeph.orderbook;

import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Defines an order issued to the simulator
 * Created by peter on 30/10/2015.
 */
public class Order {

    private static final AtomicLong idGenerator = new AtomicLong(0);

    private final long id;    // orders are currently identified just by a sequence number, no need for UUID yet
    private long quantity;    // minimum quantity is 1 share
    private Side side;
    private long price;       // price is a scaled value in 10ths of a cent (to be configurable..)

    private Order(long id, Side side, long quantity, long price) {
        this.id = id;
        this.side = side;
        this.quantity = quantity;
        this.price = price;
    }

    /**
     * Constructor for the order object
     * @param side one of buy or sell
     * @param quantity is the size of the order
     * @param price is the adjusted price in 1/1000ths of a cent
     */
    public Order(Side side, long quantity, long price) {
        this(idGenerator.incrementAndGet(), side, quantity, price);
    }

    /**
     * Gives the unique ID for this order
     * @return id
     */
    public long getId() {
        return id;
    }

    /**
     * Getter for the quantity of an order
     * @return quantity
     */
    public long getQuantity() {
        return quantity;
    }

    /**
     * Getter for the side of an order
     * @return side
     */
    public Side getSide() {
        return side;
    }

    /**
     * Getter for the price of an order
     * @return price in 10th of a cent
     */
    public long getPrice() {
        return price;
    }

    /**
     * Setter for the quantity of an order
     * @param quantity
     */
    public void setQuantity(long quantity) {
        this.quantity = quantity;
    }

    /**
     * Setter for the adjusted price of an order
     * @param price
     */
    public void setPrice(long price) {
        this.price = price;
    }
}
