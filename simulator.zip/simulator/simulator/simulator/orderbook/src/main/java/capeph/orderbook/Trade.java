package capeph.orderbook;

import java.util.UUID;

/**
 * Container for a trade
 * Created by peter on 30/10/2015.
 */
public class Trade {

    private final long price;
    private final long quantity;
    private final long buy;       // metadata that can be useful
    private final long sell;
    private final long timestamp;
    private final long removed;  // order that was removed from the book by this trade

    Trade(long buy, long sell, long removed, long quantity, long price) {
        this.buy = buy;
        this.sell = sell;
        this.removed = removed;
        this.quantity = quantity;
        this.price = price;
        timestamp = System.nanoTime();
    }

    /**
     * Getter fro the price of a trade
     * @return price in 10th of a cent
     */
    public long getPrice() {
        return price;
    }

    /**
     * Getter for the quantity of a trade.
     * @return
     */
    public long getQuantity() {
        return quantity;
    }

    long getRemoved() {
        return removed;
    }
}
