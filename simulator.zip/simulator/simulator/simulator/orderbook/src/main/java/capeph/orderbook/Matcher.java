package capeph.orderbook;

import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

/**
 * Collect trades from the orderbook
 * Created by peter on 30/10/2015.
 */
class Matcher {

    private final Order orderToFill;
    private final Side orderSide;
    private List<Trade> trades = new LinkedList<>();
    private long remainingQuantity;

    Matcher(Order toFill) {
        orderToFill = toFill;
        orderSide = toFill.getSide();
        remainingQuantity = toFill.getQuantity();
    }

    /**
     * The quantity of the current order that has ot yet been matched
     * @return unmatched quantity
     */
    long remainingQuantity() {
        return remainingQuantity;
    }

    /**
     * Include the specified order in the match. Do no perform any validation
     * @param toMatch
     * @return used quantity
     */
    long use(Order toMatch) {
        if (toMatch.getQuantity() > remainingQuantity) { // partial match
            return addTrade(toMatch, remainingQuantity);
        }
        else {
            return addTrade(toMatch, toMatch.getQuantity());
        }
    }


    private long addTrade(Order order, long filledQuantity) {
        long buyOrder = orderSide == Side.BUY ? orderToFill.getId() : order.getId();
        long sellOrder = orderSide == Side.SELL ? orderToFill.getId() : order.getId();
        long removedOrder = order.getQuantity() == filledQuantity ? order.getId() : 0;
        Trade trade = new Trade(buyOrder, sellOrder, removedOrder, filledQuantity, order.getPrice());
        trades.add(trade);
        remainingQuantity -= filledQuantity;
        return filledQuantity;
    }

    /**
     * Check if the matcher will accept an order with the given price in a match
     * @param price
     * @return true if the price can match the opposite side
     */
    boolean acceptsPrice(long price) {
        return orderSide.getComparator().compare(orderToFill.getPrice(), price) <= 0;
    }

    /**
     * only report the opposing sides of the trades
     * @return
     */
    List<Trade> getAllTrades() {
        return trades;
    }
}
