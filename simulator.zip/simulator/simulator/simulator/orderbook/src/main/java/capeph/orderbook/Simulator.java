package capeph.orderbook;

import java.io.*;
import java.util.*;

/**
 * Created by peter on 30/10/2015.
 */
public class Simulator {

    private static final double FACTOR = 1000.0;
    private static final int LEVELWIDTH = 15;
    static final String LF = System.lineSeparator();
    private static final String HELP = "Valid input is:" + LF +
            "B <volume> <price>      enter a buy order, ex 'B 10 12.5'" + LF +
            "S <volume> <price>      enter a sell order, ex 'S 10 12.5'" + LF +
            "D <id>                  delete order with id" + LF +
            "M <id> <volume> <price> modify order with id" + LF +
            "Q                     quit" + LF +
            "All numeric values must be greater than zero";

    private final Book book = new Book();

    public static void main(String[] args) {
        System.out.println("Orderbook test");
        System.out.println(HELP);
        Simulator sim = new Simulator();
        sim.cmdLoop(System.in, System.out);
    }

    private long priceToLong(double price) {
        return Math.round(price * FACTOR);
    }

    private double priceFromLong(long price) {
        return price / FACTOR;
    }


    private long getQuantity(String quantityString) {
        long quantity = Long.parseLong(quantityString);
        if (quantity <= 0) {
            throw new IllegalArgumentException("quantity must be over 0");
        }
        return quantity;
    }

    private long getAdjustedPrice(String priceString) {
        double price = Double.parseDouble(priceString);
        long adjustedPrice = priceToLong(price);
        if (adjustedPrice <= 0) {
            throw new IllegalArgumentException("price must be > 0.0");
        }
        return adjustedPrice;
    }

    Order buildOrder(Side side, String quantityString, String priceString) {
        long quantity = getQuantity(quantityString);
        long price = getAdjustedPrice(priceString);
        return new Order(side, quantity, price);
    }

    void modifyOrder(Order order, String quantityString, String priceString) {
        long quantity = getQuantity(quantityString);
        long price = getAdjustedPrice(priceString);
        order.setQuantity(quantity);
        order.setPrice(price);
    }

    String formatTrades(List<Trade> trades) {
        StringBuilder sb = new StringBuilder();
        for (Trade trade : trades) {
            sb.append(String.valueOf(trade.getQuantity()));
            sb.append("@");
            sb.append(priceFromLong(trade.getPrice()));
            sb.append(LF);
        }
        return sb.toString();
    }

    String formatLevel(Iterator<Level> iterator) {
        StringBuilder sb = new StringBuilder();
        if (iterator.hasNext()) {
            Level level = iterator.next();
            sb.append(level.getTotalQuantity());
            sb.append("@");
            sb.append(priceFromLong(level.getPrice()));
        }
        for (int i = sb.length(); i < LEVELWIDTH; ++i) {
            sb.append(" ");
        }
        return sb.toString();
    }

    String formatBook(Book book) {
        Collection<Level> bids = book.getBids();
        Collection<Level> offers = book.getOffers();
        Iterator<Level> biderator = bids.iterator();
        Iterator<Level> offerator = offers.iterator();
        StringBuilder sb = new StringBuilder();
        sb.append("   Buy            |   Sell");
        sb.append(LF);
        while (biderator.hasNext() || offerator.hasNext()) {
            sb.append("   ");
            sb.append(formatLevel(biderator));
            sb.append("|");
            sb.append("   ");
            sb.append(formatLevel(offerator));
            sb.append(LF);
        }
        return sb.toString();
    }

    String formatOrder(Order order) {
        StringBuilder sb = new StringBuilder();
        sb.append(order.getId());
        sb.append(":");
        sb.append(order.getSide() == Side.BUY ?  "B" : "S");
        sb.append(order.getQuantity());
        sb.append("@");
        sb.append(priceFromLong(order.getPrice()));
        sb.append(LF);
        return sb.toString();
    }

    Optional<String> handleCommand(String inputLine) {
        StringTokenizer tokenizer = new StringTokenizer(inputLine);
        String error = "unknwon command";
        try {
            String command = tokenizer.nextToken().toUpperCase();
            if ("B".equals(command)) {
                Order order = buildOrder(Side.BUY, tokenizer.nextToken(), tokenizer.nextToken());
                List<Trade> trades = book.buy(order);
                return Optional.of(formatOrder(order) + formatTrades(trades) + formatBook(book));
            }
            if ("S".equals(command)) {
                Order order = buildOrder(Side.SELL, tokenizer.nextToken(), tokenizer.nextToken());
                List<Trade> trades = book.sell(order);
                return Optional.of(formatOrder(order) + formatTrades(trades) + formatBook(book));
            }
            if ("D".equals(command)) {
                long id = Long.parseLong(tokenizer.nextToken());
                book.remove(id);
                return Optional.of(formatBook(book));
            }
            if ("M".equals(command)) {
                long id = Long.parseLong(tokenizer.nextToken());
                Order order = book.remove(id);
                if (order == null) {
                    return Optional.of("No such order");
                }
                modifyOrder(order, tokenizer.nextToken(), tokenizer.nextToken());
                List<Trade> trades = order.getSide() == Side.BUY ? book.buy(order) : book.sell(order);
                return Optional.of(formatOrder(order) + formatTrades(trades) + formatBook(book));
            }
            if ("Q".equals(command)) {
                return Optional.empty();
            }
        }
        catch (Exception e) {
            error = e.getMessage();
        }
        return Optional.of("Illegal input: " + error + LF + HELP);
    }

    void cmdLoop(InputStream in, PrintStream out) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        try {
            boolean parseInput = true;
            while (parseInput) {
                String line = reader.readLine();
                Optional<String> result = handleCommand(line);
                out.println(result.orElse("bye!"));
                parseInput = result.isPresent();
            }
        }
        catch (IOException e) {
            out.println("Error getting input - terminating");
        }
    }
}
