package capeph.orderbook;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * A list of orders with the same price stored in the order they were entered into the system
 * Created by peter on 30/10/2015.
 */
class Level {

    // store the entire order for readability. could get away with just storing id and quantity
    private final Map<Long, Order> orderSequence = new LinkedHashMap<>();  // to allow random access
    private final long price;
    private long totalQuantity = 0;

    Level(long price) {
        this.price = price;
    }

    public long getPrice() {
        return price;
    }

    public long getTotalQuantity() {
        return totalQuantity;
    }

    void add(Order order) {
        orderSequence.put(order.getId(), order);
        totalQuantity += order.getQuantity();
    }

    void match(Matcher matcher) {
        Iterator<Order> it = orderSequence.values().iterator();
        while (it.hasNext() && matcher.remainingQuantity() > 0) {
            Order toMatch = it.next();
            long matchedQuantity = matcher.use(toMatch);
            totalQuantity -= matchedQuantity;
            if (matchedQuantity < toMatch.getQuantity()) {
                toMatch.setQuantity(toMatch.getQuantity() - matchedQuantity);
            }
            else {
                it.remove();
            }
        }
    }


    public Order remove(Order order) {
        Order result = orderSequence.remove((order.getId()));
        if (result != null) {
            totalQuantity -= result.getQuantity();
        }
        return result;
    }
}
