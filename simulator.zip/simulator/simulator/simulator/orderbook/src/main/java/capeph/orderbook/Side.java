package capeph.orderbook;

import java.util.Comparator;

/**
 * Enum for describing the side of an order.
 * possible values are buy and sell
 * Created by peter on 30/10/2015.
 */
public enum Side {
    BUY((x, y) -> Long.compare(y, x)),      // we want buy orders sorted in reverse order
    SELL((x, y) -> Long.compare(x, y));     // sell orders are sorted in rising order

    private final Comparator<? super Long> comparator;

    Side(Comparator<? super Long> comparator) {
        this.comparator = comparator;
    }

    /**
     * translate a side given by a char into a Side enum instance.
     * @param ch
     * @return a valid side
     */
    public static Side fromChar(char ch) {
        switch (ch) {
            case 'b':
            case 'B':
                return BUY;
            case 's':
            case 'S':
                return SELL;
            default:
                throw new IllegalArgumentException("Invalid value used for side, must be one of [b,B,s,S], was " + ch);
        }
    }

    /**
     * returns a comparator that is used for the orders of price levels in the order book.
     * @return
     */
    Comparator<? super Long> getComparator() {
        return comparator;
    }
}
