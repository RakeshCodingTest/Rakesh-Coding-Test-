package capeph.orderbook;

import java.util.*;

/**
 * Created by peter on 30/10/2015.
 */
class Depth {

    private final SortedMap<Long, Level> depthMap;

    Depth(Side side) {
        // TODO - replace with map handling native values for better performance
        depthMap = new TreeMap<>(side.getComparator());
    }

    private Level getDepthLevel(long price) {
        Level level = depthMap.get(price);
        if (level == null) {
            // TODO - lazy init can cause performance issues
            level = new Level(price);
            depthMap.put(price, level);
        }
        return level;
    }

    void add(Order order) {
        Level level = getDepthLevel(order.getPrice());
        level.add(order);
    }

    void match(Matcher matcher) {
        Iterator<Level> it = depthMap.values().iterator();
        while(it.hasNext() && matcher.remainingQuantity() > 0) {
            Level level = it.next();
            if (!matcher.acceptsPrice(level.getPrice())) {
                break;
            }
            level.match(matcher);
            if (level.getTotalQuantity() == 0) {
                it.remove();
            }
        }
    }

    Collection<Level> getLevels() {
        return depthMap.values();
    }

    Order remove(Order order) {
        Level level = depthMap.get(order.getPrice());
        if (level != null) {
            Order result = level.remove(order);
            if (result != null && level.getTotalQuantity() == 0) {
                depthMap.remove(order.getPrice());
            }
            return result;
        }
        return null;
    }
}
