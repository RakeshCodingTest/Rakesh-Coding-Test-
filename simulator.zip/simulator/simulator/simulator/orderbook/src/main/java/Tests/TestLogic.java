package Tests;
import static org.junit.Assert.*;

import capeph.orderbook.Simulator;
import org.junit.Test;

public class TestLogic {

    @Test
    public  void test() {
        // Test 1 -> PASSED
        /*
        build order using B 100 9.9
        assertequals
        Buy            |   Sell
        100@9.9        |


        Test 2 -> PASSED

        build order using B 1000 10
        assertequals
        Buy            |   Sell
       1000@10.0      |
       100@9.9        |


        Test 3 -> PASSED

        build order using B 1000 10
        assertequals
        Buy            |   Sell
       1000@10.0      |
       100@9.9        |

        Test 3 -> Passed

        build order using S 100 10.1
        assertequals
        Buy            |   Sell
       1000@10.0      |   100@10.1
       100@9.9        |

        Test 4 -> Failed
        build order using S 50 9.9
        assertequals

        Actual:
         Buy            |   Sell
       950@10.0       |   100@10.1
       100@9.9        |


        Expected:
         Buy            |   Sell
      1000@10.0      |   100@10.1
       100@9.9        |   50@9.9

        Test 5: Passed
        Enter Q
        Display bye!

        Test 6: Passed
        B 50 10
        1:B50@10.0
           Buy            |   Sell
           50@10.0        |

        S 100 10
        2:S50@10.0
        50@10.0
           Buy            |   Sell
                           |   50@10.0

         */



    }
}
